



# 八 微服务/分布式

概览（看看自己能回答几题）：

1. 为什么要网关？
2. 你知道有哪些常见的网关系统？
3. 限流的算法有哪些？
4. 为什么要分布式 id ？
5. 分布式 id 生成策略有哪些？
6. 了解RPC吗？
7. 有哪些常见的 RPC 框架？
8. 如果让你自己设计 RPC 框架你会如何设计？
9. Dubbo 了解吗？
10. Dubbo 提供了哪些负载均衡策略？
11. 谈谈你对微服务领域的了解和认识！

答案地址：[https://t.zsxq.com/F6yrJiI](https://t.zsxq.com/F6yrJiI ) 。这部分内容的答案更新在[知识星球](http://mp.weixin.qq.com/s?__biz=Mzg2OTA0Njk0OA==&mid=100013795&idx=1&sn=aa2db4799c432bb944b6786ae0ec4c56&chksm=4ea1b92879d6303e9077546e2bc42a78f0cd3e18d9adb06e9f15e49e3d8337ec4bd384a25367#rd)。

